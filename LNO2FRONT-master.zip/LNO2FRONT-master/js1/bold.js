function Bold() {
    document.getElementById("myTextArea").style.fontWeight = 'bold'; 
}