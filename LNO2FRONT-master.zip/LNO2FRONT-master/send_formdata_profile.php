<?php
$link = mysqli_connect("localhost","root","anmol1998")  or die("failed to connect to server !!");
mysqli_select_db($link,"profile_info");
if(isset($_REQUEST['submit']))
{
$errorMessage = "";
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$gender=$_POST['gender'];
$dob=$_POST['dob'];
$currentcity=$_POST['currentcity'];
$hometown=$_POST['hometown'];
$school=$_POST['school'];
$college=$_POST['college'];
$telephone=$_POST['telephone'];
$email=$_POST['email'];
$description=$_POST['description'];
 
// Validation will be added here
 
if ($errorMessage != "" ) {
echo "<p class='message'>" .$errorMessage. "</p>" ;
}
else{
//Inserting record in table using INSERT query
$insqDbtb="INSERT INTO `profile_info`.`members`
(`firstname`, `lastname`, `gender`, `dob`, `currentcity`,
`hometown`, `school`, `college`, `telephone`, `email`, `description`) VALUES ('$firstname', '$lastname', 
'$gender', '$dob', '$currentcity', '$hometown', '$school', '$college', '$telephone', '$email', '$description')";
mysqli_query($link,$insqDbtb) or die(mysqli_error($link));
}
}
?>